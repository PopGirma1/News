    <?php
     $fname = filter_input(INPUT_POST, 'fname');
     $lname = filter_input(INPUT_POST, 'lname');
     $email = filter_input(INPUT_POST, 'email');
     $phone = filter_input(INPUT_POST, 'phone');
     $comment= filter_input(INPUT_POST, 'comment');

     if (!empty($email)){

    if (!empty($comment)){

    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "newsportal";
    // Create connection
    $conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
    if (mysqli_connect_error()){
    die('Connect Error ('. mysqli_connect_errno() .') '
    . mysqli_connect_error());
    }


    else{






    $sql = "INSERT INTO contact (fname,lname,email,phone,comment)
    values ('$fname','$lname','$email','$phone','$comment')";


    if ($conn->query($sql)){
   header("Location:header.php");

    }


    else{
    echo "Error: ". $sql ."
    ". $conn->error;
    }
    $conn->close();


    }


    }

    else{
    echo "comment should not be empty";
    die();
    }

    }
    else{
    echo " email should not be empty";
    die();
    }
    ?>